import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import crypto from 'node:crypto';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import helmet from 'helmet';
import compression from 'compression';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import cron from 'node-cron';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const app = express();
const port = Number(process.env.PORT || 3000);
const jwtSecret = process.env.JWT_SECRET;
if (!jwtSecret || jwtSecret.length < 32) {
  console.error('CONFIG ERROR: set JWT_SECRET to a random string with at least 32 characters in .env');
  process.exit(1);
}
fs.mkdirSync(path.join(root, 'data'), { recursive: true });
const db = new Database(process.env.DB_PATH || path.join(root, 'data', 'hunter.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL, last_login_at TEXT
);
CREATE TABLE IF NOT EXISTS workspaces (
 user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 data_json TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS research_runs (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 query TEXT NOT NULL, status TEXT NOT NULL, results_json TEXT NOT NULL DEFAULT '[]',
 error TEXT, created_at TEXT NOT NULL, finished_at TEXT
);
CREATE TABLE IF NOT EXISTS scheduled_tasks (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title TEXT NOT NULL, task_json TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 0,
 interval_minutes INTEGER NOT NULL DEFAULT 1440, next_run_at TEXT, last_run_at TEXT,
 status TEXT NOT NULL DEFAULT 'paused', created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_research_user_date ON research_runs(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_tasks_due ON scheduled_tasks(enabled, next_run_at);
`);

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(compression());
app.use(express.json({ limit: '2mb' }));
const origins = (process.env.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
app.use(cors({ origin(origin, cb) { if (!origin || !origins.length || origins.includes(origin)) return cb(null, true); return cb(new Error('Origin not allowed')); }, credentials: false }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));
app.use('/api', rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false }));
app.use('/api/research', rateLimit({ windowMs: 60 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false }));
app.use('/api/ai', rateLimit({ windowMs: 60 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));

const now = () => new Date().toISOString();
const id = () => crypto.randomUUID();
const auth = (req, res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) return res.status(401).json({ error: 'Faça login para continuar.' });
  try { req.user = jwt.verify(token, jwtSecret); next(); }
  catch { return res.status(401).json({ error: 'Sessão inválida ou expirada. Entre novamente.' }); }
};
const safeUser = user => ({ id: user.id, email: user.email });
const sign = user => jwt.sign({ sub: user.id, email: user.email }, jwtSecret, { expiresIn: '7d', issuer: 'hunter-pro-ultra' });

app.get('/api/health', (_req, res) => res.json({ ok: true, product: 'Hunter Pro Ultra', version: '3.0.0', time: now(), integrations: { database: 'connected', webSearch: process.env.BRAVE_SEARCH_API_KEY ? 'configured' : 'not_configured', ai: process.env.AI_API_KEY ? 'configured' : 'not_configured' } }));

app.post('/api/auth/signup', async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Informe um e-mail válido.' });
  if (password.length < 10) return res.status(400).json({ error: 'A senha precisa ter pelo menos 10 caracteres.' });
  if (password.length > 200) return res.status(400).json({ error: 'Senha muito longa.' });
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) return res.status(409).json({ error: 'Este e-mail já possui uma conta. Entre em vez de criar outra.' });
  const user = { id: id(), email, password_hash: await bcrypt.hash(password, 12), created_at: now() };
  db.prepare('INSERT INTO users (id,email,password_hash,created_at) VALUES (?,?,?,?)').run(user.id, user.email, user.password_hash, user.created_at);
  return res.status(201).json({ token: sign(user), user: safeUser(user) });
});
app.post('/api/auth/login', async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
  db.prepare('UPDATE users SET last_login_at = ? WHERE id = ?').run(now(), user.id);
  return res.json({ token: sign(user), user: safeUser(user) });
});
app.get('/api/auth/me', auth, (req, res) => {
  const user = db.prepare('SELECT id,email FROM users WHERE id = ?').get(req.user.sub);
  if (!user) return res.status(401).json({ error: 'Conta não encontrada.' });
  res.json({ user });
});

app.get('/api/workspace', auth, (req, res) => {
  const row = db.prepare('SELECT data_json, updated_at FROM workspaces WHERE user_id = ?').get(req.user.sub);
  if (!row) return res.json({ data: null, updatedAt: null });
  try { return res.json({ data: JSON.parse(row.data_json), updatedAt: row.updated_at }); }
  catch { return res.status(500).json({ error: 'O workspace salvo não pôde ser lido.' }); }
});
app.put('/api/workspace', auth, (req, res) => {
  const data = req.body?.data;
  if (!data || typeof data !== 'object' || Array.isArray(data)) return res.status(400).json({ error: 'Formato de workspace inválido.' });
  const json = JSON.stringify(data);
  if (Buffer.byteLength(json, 'utf8') > 1_500_000) return res.status(413).json({ error: 'Workspace acima do limite de 1,5 MB. Exporte arquivos grandes separadamente.' });
  const updatedAt = now();
  db.prepare(`INSERT INTO workspaces(user_id,data_json,updated_at) VALUES(?,?,?)
    ON CONFLICT(user_id) DO UPDATE SET data_json=excluded.data_json, updated_at=excluded.updated_at`).run(req.user.sub, json, updatedAt);
  res.json({ ok: true, updatedAt });
});

// Real web search through Brave Search API. Results are source-backed search results, not verified leads.
app.post('/api/research', auth, async (req, res) => {
  const city = String(req.body?.city || '').trim().slice(0, 120);
  const niche = String(req.body?.niche || '').trim().slice(0, 100);
  const service = String(req.body?.service || '').trim().slice(0, 150);
  const criteria = String(req.body?.criteria || '').trim().slice(0, 160);
  if (!city || !niche) return res.status(400).json({ error: 'Informe cidade/região e nicho.' });
  if (!process.env.BRAVE_SEARCH_API_KEY) return res.status(503).json({ error: 'Pesquisa web não configurada. Adicione BRAVE_SEARCH_API_KEY ao ambiente do servidor.', integration: 'BRAVE_SEARCH_API_KEY' });
  const query = `${niche} ${city} empresas ${criteria === 'Site ausente ou desatualizado' ? '(site OR website OR contato)' : ''}`.trim().slice(0, 400);
  const runId = id();
  db.prepare('INSERT INTO research_runs(id,user_id,query,status,created_at) VALUES(?,?,?,?,?)').run(runId, req.user.sub, query, 'running', now());
  try {
    const url = new URL('https://api.search.brave.com/res/v1/web/search');
    url.searchParams.set('q', query); url.searchParams.set('count', '10'); url.searchParams.set('country', 'BR'); url.searchParams.set('search_lang', 'pt-br');
    const response = await fetch(url, { headers: { 'X-Subscription-Token': process.env.BRAVE_SEARCH_API_KEY, Accept: 'application/json' }, signal: AbortSignal.timeout(15000) });
    if (!response.ok) throw new Error(`Provedor de pesquisa retornou HTTP ${response.status}`);
    const payload = await response.json();
    const results = (payload.web?.results || []).map(r => ({ title: String(r.title || '').slice(0, 300), url: String(r.url || ''), description: String(r.description || '').slice(0, 1200), source: new URL(r.url).hostname, fetchedAt: now(), verifiedLead: false }));
    db.prepare('UPDATE research_runs SET status=?,results_json=?,finished_at=? WHERE id=?').run('completed', JSON.stringify(results), now(), runId);
    res.json({ runId, query, results, note: 'Resultados reais de pesquisa web; confirme cada empresa e contato antes de qualificar como lead.' });
  } catch (err) {
    db.prepare('UPDATE research_runs SET status=?,error=?,finished_at=? WHERE id=?').run('failed', String(err.message || 'Falha de pesquisa').slice(0, 500), now(), runId);
    res.status(502).json({ error: 'A pesquisa não foi concluída.', detail: String(err.message || '').slice(0, 300), runId });
  }
});
app.get('/api/research/history', auth, (req, res) => {
  const rows = db.prepare('SELECT id,query,status,error,created_at,finished_at FROM research_runs WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(req.user.sub);
  res.json({ runs: rows });
});

app.post('/api/ai/generate', auth, async (req, res) => {
  if (!process.env.AI_API_KEY) return res.status(503).json({ error: 'IA não configurada. Adicione AI_API_KEY ao ambiente do servidor.', integration: 'AI_API_KEY' });
  const task = String(req.body?.task || '').slice(0, 120);
  const prompt = String(req.body?.prompt || '').trim().slice(0, 12000);
  if (!prompt) return res.status(400).json({ error: 'Informe o pedido para a IA.' });
  const base = (process.env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
  try {
    const response = await fetch(`${base}/chat/completions`, { method: 'POST', headers: { Authorization: `Bearer ${process.env.AI_API_KEY}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: process.env.AI_MODEL || 'gpt-4.1-mini', temperature: 0.5, messages: [{ role: 'system', content: 'Você é o assistente comercial do Hunter Pro Ultra. Seja preciso, não invente dados sobre empresas e diferencie fatos fornecidos pelo usuário de hipóteses.' }, { role: 'user', content: `Tipo de tarefa: ${task || 'assistência comercial'}\n\n${prompt}` }] }), signal: AbortSignal.timeout(45000) });
    if (!response.ok) throw new Error(`Provedor de IA retornou HTTP ${response.status}`);
    const payload = await response.json();
    const text = payload.choices?.[0]?.message?.content;
    if (!text) throw new Error('Resposta vazia do provedor de IA.');
    res.json({ text, model: payload.model || process.env.AI_MODEL || 'configured-model', usage: payload.usage || null });
  } catch (err) { res.status(502).json({ error: 'Não foi possível concluir a tarefa de IA.', detail: String(err.message || '').slice(0, 300) }); }
});

app.get('/api/tasks', auth, (req, res) => {
  const tasks = db.prepare('SELECT id,title,task_json,enabled,interval_minutes,next_run_at,last_run_at,status,created_at FROM scheduled_tasks WHERE user_id=? ORDER BY created_at DESC').all(req.user.sub).map(t => ({ ...t, task: JSON.parse(t.task_json), enabled: !!t.enabled }));
  res.json({ tasks });
});
app.post('/api/tasks', auth, (req, res) => {
  const title = String(req.body?.title || '').trim().slice(0, 120);
  const task = req.body?.task;
  const interval = Math.max(1440, Math.min(10080, Number(req.body?.intervalMinutes || 1440)));
  const taskCount = db.prepare('SELECT COUNT(*) AS n FROM scheduled_tasks WHERE user_id=?').get(req.user.sub).n;
  if (taskCount >= 5) return res.status(429).json({ error: 'Limite de 5 tarefas agendadas por workspace atingido.' });
  if (!title || !task || typeof task !== 'object') return res.status(400).json({ error: 'Informe nome e configuração da tarefa.' });
  const taskId = id(); const createdAt = now(); const nextRun = new Date(Date.now() + interval * 60000).toISOString();
  db.prepare('INSERT INTO scheduled_tasks(id,user_id,title,task_json,enabled,interval_minutes,next_run_at,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)').run(taskId, req.user.sub, title, JSON.stringify(task), 0, interval, nextRun, 'paused', createdAt);
  res.status(201).json({ id: taskId, title, enabled: false, nextRunAt: nextRun, status: 'paused', note: 'Criada pausada. Ative após configurar a pesquisa e os limites.' });
});
app.patch('/api/tasks/:id', auth, (req, res) => {
  const task = db.prepare('SELECT * FROM scheduled_tasks WHERE id=? AND user_id=?').get(req.params.id, req.user.sub);
  if (!task) return res.status(404).json({ error: 'Tarefa não encontrada.' });
  const enabled = typeof req.body?.enabled === 'boolean' ? req.body.enabled : !!task.enabled;
  const status = enabled ? 'scheduled' : 'paused';
  const nextRun = enabled ? new Date(Date.now() + task.interval_minutes * 60000).toISOString() : task.next_run_at;
  db.prepare('UPDATE scheduled_tasks SET enabled=?,status=?,next_run_at=? WHERE id=? AND user_id=?').run(enabled ? 1 : 0, status, nextRun, task.id, req.user.sub);
  res.json({ ok: true, enabled, status, nextRunAt: nextRun });
});
app.delete('/api/tasks/:id', auth, (req, res) => { const info = db.prepare('DELETE FROM scheduled_tasks WHERE id=? AND user_id=?').run(req.params.id, req.user.sub); if (!info.changes) return res.status(404).json({ error: 'Tarefa não encontrada.' }); res.json({ ok: true }); });

// Scheduler executes enabled research tasks while the hosted Node process is running.
cron.schedule('* * * * *', async () => {
  const due = db.prepare("SELECT * FROM scheduled_tasks WHERE enabled=1 AND next_run_at IS NOT NULL AND next_run_at <= ? LIMIT 5").all(now());
  for (const task of due) {
    const nextRun = new Date(Date.now() + task.interval_minutes * 60000).toISOString();
    db.prepare("UPDATE scheduled_tasks SET status='running',last_run_at=?,next_run_at=? WHERE id=?").run(now(), nextRun, task.id);
    try {
      const cfg = JSON.parse(task.task_json);
      if (!process.env.BRAVE_SEARCH_API_KEY) throw new Error('BRAVE_SEARCH_API_KEY não configurada');
      const query = `${String(cfg.niche || '').slice(0,100)} ${String(cfg.city || '').slice(0,120)} empresas`.trim();
      const url = new URL('https://api.search.brave.com/res/v1/web/search'); url.searchParams.set('q', query); url.searchParams.set('count', String(Math.max(1, Math.min(10, Number(cfg.limit || 10))))); url.searchParams.set('country', 'BR'); url.searchParams.set('search_lang', 'pt-br');
      const response = await fetch(url, { headers: { 'X-Subscription-Token': process.env.BRAVE_SEARCH_API_KEY, Accept: 'application/json' }, signal: AbortSignal.timeout(15000) });
      if (!response.ok) throw new Error(`Search HTTP ${response.status}`);
      const payload = await response.json(); const results = payload.web?.results || [];
      const runId = id(); db.prepare('INSERT INTO research_runs(id,user_id,query,status,results_json,created_at,finished_at) VALUES(?,?,?,?,?,?,?)').run(runId, task.user_id, query, 'completed', JSON.stringify(results), now(), now());
      db.prepare("UPDATE scheduled_tasks SET status='scheduled' WHERE id=?").run(task.id);
    } catch (err) { db.prepare("UPDATE scheduled_tasks SET status=? WHERE id=?").run(`error: ${String(err.message || 'falha').slice(0,120)}`, task.id); }
  }
});

app.use(express.static(root, { extensions: ['html'], maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0 }));
app.get('*', (req, res, next) => { if (req.path.startsWith('/api/')) return next(); res.sendFile(path.join(root, 'index.html')); });
app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error: 'Erro interno. Consulte os logs do servidor.' }); });
app.listen(port, '0.0.0.0', () => console.log(`Hunter Pro Ultra running on port ${port}`));
