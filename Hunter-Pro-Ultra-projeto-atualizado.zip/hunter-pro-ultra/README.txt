HUNTER PRO ULTRA — ENZO · VERSÃO FULL-STACK 3.0
================================================

ISTO É UM PROJETO WEB FULL-STACK, NÃO UM SITE PUBLICADO
------------------------------------------------------
O pacote contém a interface web, API de backend, autenticação, persistência SQLite, pesquisa web por provedor configurado, geração por IA opcional e scheduler de tarefas. Ainda é necessário instalar dependências, configurar chaves e publicar numa hospedagem sob sua conta antes de vender o serviço como SaaS.

O QUE FUNCIONA NO CÓDIGO
-----------------------
- Interface responsiva com animações, dashboard, CRM, Studio e páginas comerciais.
- O Studio gera uma página HTML responsiva e exportável com seções e interações.
- Login e criação de conta no backend com hash de senha, JWT, rate limits e isolamento do workspace por usuário.
- Persistência do workspace no SQLite do servidor e sincronização automática após login.
- Endpoint de pesquisa real por Brave Search API, exibindo links e fontes; os resultados precisam ser verificados antes de virarem leads.
- Integração opcional com API compatível com OpenAI para mensagens e edição do Studio.
- Tarefas agendadas no backend, com intervalo mínimo de 24 horas e limite de cinco tarefas por workspace. A rotina guarda resultados de pesquisa; não envia mensagens comerciais automaticamente.
- Histórico de pesquisas, status de integrações e limites básicos de requisições.
- Arquivo Dockerfile e blueprint render.yaml para implantação como serviço Node.

O QUE DEPENDE DE CONFIGURAÇÃO
-----------------------------
- Publicação em hospedagem e domínio: ainda não foi feita nesta conversa; requer conta/credenciais do provedor.
- Pesquisa real: requer BRAVE_SEARCH_API_KEY no ambiente do servidor.
- IA: requer AI_API_KEY e, opcionalmente, AI_BASE_URL e AI_MODEL.
- O banco SQLite precisa de armazenamento persistente na hospedagem. O render.yaml configura um disco persistente para Render.
- WhatsApp Business, e-mail, pagamentos, publicação automática de sites e domínio personalizado não estão conectados neste pacote.
- O Studio exporta sites HTML; publicação automática do site de cada cliente ainda precisa de integração de hospedagem.

RODAR LOCALMENTE (NODE.JS 20+)
------------------------------
1. Extraia o ZIP.
2. Instale Node.js 20 ou superior.
3. Copie .env.example para .env.
4. Defina JWT_SECRET com uma string aleatória forte de pelo menos 32 caracteres.
5. Opcional: preencha BRAVE_SEARCH_API_KEY para pesquisa real.
6. Opcional: preencha AI_API_KEY para usar IA no backend.
7. No terminal, dentro da pasta do projeto, rode: npm install
8. Rode: npm start
9. Abra http://localhost:3000 no navegador.
10. Clique no perfil “Enzo”, crie uma conta e faça login para sincronizar o workspace.

PUBLICAR NO RENDER
------------------
1. Crie um repositório privado no GitHub e envie o conteúdo desta pasta.
2. No Render, crie um Web Service conectado ao repositório e use render.yaml (Blueprint) ou configure build command `npm install` e start command `npm start`.
3. Configure JWT_SECRET como secret e, quando disponíveis, BRAVE_SEARCH_API_KEY e AI_API_KEY como secrets no ambiente do serviço.
4. Confirme que o disco persistente está montado em /opt/render/project/src/data.
5. Aguarde o deploy e teste /api/health. Crie uma conta e teste sincronização, pesquisa e agendamento.
6. Antes de vender, configure domínio/HTTPS, backups, política de privacidade, termos, monitoramento e testes de segurança.

SEGURANÇA E LIMITES
-------------------
- Nunca coloque chaves de API no HTML ou JavaScript do navegador.
- Use um JWT_SECRET exclusivo e forte. Não envie o arquivo .env para o GitHub.
- A conta de teste não deve ser usada para dados reais até revisar hospedagem, backups, recuperação de conta, cookies/sessões, logs, privacidade e controles de abuso.
- As pesquisas automáticas não verificam por si só se uma empresa não possui site; são resultados de busca com fonte. Inspecione a evidência antes de afirmar problemas ou abordar a empresa.
- Não existe envio automático de mensagens. Revise e aprove abordagens comerciais manualmente.
- Não declare o produto como 100% pronto para produção sem executar testes de integração e segurança na hospedagem final.
